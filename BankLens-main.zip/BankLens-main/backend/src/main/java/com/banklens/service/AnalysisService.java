package com.banklens.service;

import com.banklens.dto.AnalysisResponse;
import com.banklens.dto.AnalysisSummaryDto;
import com.banklens.entity.Analysis;
import com.banklens.entity.User;
import com.banklens.exception.BankLensExceptions;
import com.banklens.repository.AnalysisRepository;
import com.banklens.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class AnalysisService {

    private static final Logger log = LoggerFactory.getLogger(AnalysisService.class);

    private final AnalysisRepository analysisRepository;
    private final UserRepository userRepository;
    private final PdfParserService pdfParser;
    private final AnthropicService anthropicService;
    private final RateLimitService rateLimitService;
    private final ObjectMapper objectMapper;

    public AnalysisService(AnalysisRepository analysisRepository,
                           UserRepository userRepository,
                           PdfParserService pdfParser,
                           AnthropicService anthropicService,
                           RateLimitService rateLimitService,
                           ObjectMapper objectMapper) {
        this.analysisRepository = analysisRepository;
        this.userRepository = userRepository;
        this.pdfParser = pdfParser;
        this.anthropicService = anthropicService;
        this.rateLimitService = rateLimitService;
        this.objectMapper = objectMapper;
    }

    @Transactional
    public AnalysisResponse analyze(MultipartFile file, String userEmail) {
        User user = findUser(userEmail);
        rateLimitService.checkAnalysisLimit(user.getId().toString());
        rateLimitService.checkRequestRate(user.getId().toString());
        String pdfText = pdfParser.extractText(file);
        log.info("PDF extracted: {} chars for user {}", pdfText.length(), userEmail);
        AnalysisResponse response = anthropicService.analyzeStatement(pdfText);
        log.info("Analysis complete: {} transactions, risk={}", response.getTxnCount(), response.getRiskScore());
        try {
            String analysisJson = objectMapper.writeValueAsString(response);
            Analysis analysis = Analysis.builder()
                    .user(user)
                    .fileName(file.getOriginalFilename())
                    .period(response.getPeriod())
                    .account(maskAccount(response.getAccount()))
                    .analysisJson(analysisJson)
                    .riskScore(response.getRiskScore())
                    .riskLevel(response.getRiskLevel())
                    .totalCredits(response.getTotalCredits())
                    .totalDebits(response.getTotalDebits())
                    .build();
            Analysis saved = analysisRepository.save(analysis);
            response.setId(saved.getId());
            response.setCreatedAt(saved.getCreatedAt());
            response.setAccount(saved.getAccount());
        } catch (Exception e) {
            log.error("Failed to persist analysis", e);
        }
        return response;
    }

    @Transactional(readOnly = true)
    public List<AnalysisSummaryDto> getHistory(String userEmail, int page, int size) {
        User user = findUser(userEmail);
        Page<Analysis> analyses = analysisRepository.findByUserOrderByCreatedAtDesc(
                user, PageRequest.of(page, size, Sort.by("createdAt").descending()));
        return analyses.getContent().stream()
                .map(this::toSummary)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public AnalysisResponse getAnalysis(UUID id, String userEmail) {
        User user = findUser(userEmail);
        Analysis analysis = analysisRepository.findByIdAndUser(id, user)
                .orElseThrow(() -> new BankLensExceptions.AnalysisNotFoundException(id.toString()));
        try {
            AnalysisResponse response = objectMapper.readValue(analysis.getAnalysisJson(), AnalysisResponse.class);
            response.setId(analysis.getId());
            response.setCreatedAt(analysis.getCreatedAt());
            return response;
        } catch (Exception e) {
            log.error("Failed to deserialize analysis {}", id, e);
            throw new BankLensExceptions.AnalysisNotFoundException(id.toString());
        }
    }

    @Transactional
    public void deleteAnalysis(UUID id, String userEmail) {
        User user = findUser(userEmail);
        Analysis analysis = analysisRepository.findByIdAndUser(id, user)
                .orElseThrow(() -> new BankLensExceptions.AnalysisNotFoundException(id.toString()));
        analysisRepository.delete(analysis);
    }

    public long getRemainingAnalyses(String userEmail) {
        User user = findUser(userEmail);
        return rateLimitService.getRemainingAnalyses(user.getId().toString());
    }

    private User findUser(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(BankLensExceptions.InvalidCredentialsException::new);
    }

    private AnalysisSummaryDto toSummary(Analysis a) {
        return AnalysisSummaryDto.builder()
                .id(a.getId())
                .period(a.getPeriod())
                .account(a.getAccount())
                .fileName(a.getFileName())
                .riskScore(a.getRiskScore() != null ? a.getRiskScore() : 0)
                .riskLevel(a.getRiskLevel())
                .totalCredits(a.getTotalCredits() != null ? a.getTotalCredits() : 0)
                .totalDebits(a.getTotalDebits() != null ? a.getTotalDebits() : 0)
                .createdAt(a.getCreatedAt())
                .build();
    }

    private String maskAccount(String account) {
        if (account == null || account.length() <= 4) return account;
        String digits = account.replaceAll("[^0-9]", "");
        if (digits.length() >= 4) {
            return "••" + digits.substring(digits.length() - 4);
        }
        return account;
    }
}