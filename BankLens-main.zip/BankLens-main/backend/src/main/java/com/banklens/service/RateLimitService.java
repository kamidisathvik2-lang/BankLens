package com.banklens.service;

import com.banklens.exception.BankLensExceptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

@Service
public class RateLimitService {

    private static final Logger log = LoggerFactory.getLogger(RateLimitService.class);

    private final RedisTemplate<String, Object> redisTemplate;
    private final int analysesPerDay;
    private final int requestsPerMinute;

    public RateLimitService(RedisTemplate<String, Object> redisTemplate,
                            @Value("${banklens.rate-limit.analyses-per-day}") int analysesPerDay,
                            @Value("${banklens.rate-limit.requests-per-minute}") int requestsPerMinute) {
        this.redisTemplate = redisTemplate;
        this.analysesPerDay = analysesPerDay;
        this.requestsPerMinute = requestsPerMinute;
    }

    public void checkAnalysisLimit(String userId) {
        String key = "rate:analysis:daily:" + userId + ":" + todayKey();
        Long count = redisTemplate.opsForValue().increment(key);
        if (count != null && count == 1) {
            redisTemplate.expire(key, 25, TimeUnit.HOURS);
        }
        if (count != null && count > analysesPerDay) {
            throw new BankLensExceptions.RateLimitExceededException(
                    "Daily analysis limit reached (" + analysesPerDay + "/day). Try again tomorrow.");
        }
    }

    public void checkRequestRate(String userId) {
        String key = "rate:requests:minute:" + userId;
        Long count = redisTemplate.opsForValue().increment(key);
        if (count != null && count == 1) {
            redisTemplate.expire(key, Duration.ofMinutes(1));
        }
        if (count != null && count > requestsPerMinute) {
            throw new BankLensExceptions.RateLimitExceededException(
                    "Too many requests. Please wait before trying again.");
        }
    }

    public long getRemainingAnalyses(String userId) {
        String key = "rate:analysis:daily:" + userId + ":" + todayKey();
        Object val = redisTemplate.opsForValue().get(key);
        long used = val == null ? 0L : Long.parseLong(val.toString());
        return Math.max(0, analysesPerDay - used);
    }

    private String todayKey() {
        return java.time.LocalDate.now().toString();
    }
}