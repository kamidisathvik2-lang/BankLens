package com.banklens.controller;

import com.banklens.service.AnthropicService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class ChatController {

    private final AnthropicService anthropicService;

    public ChatController(AnthropicService anthropicService) {
        this.anthropicService = anthropicService;
    }

    @PostMapping("/chat")
    public ResponseEntity<Map<String, String>> chat(
            @RequestBody Map<String, Object> body,
            @AuthenticationPrincipal UserDetails userDetails) {

        String question = (String) body.get("question");
        Object context = body.get("context");

        String contextJson;
        try {
            contextJson = new ObjectMapper().writeValueAsString(context);
        } catch (Exception e) {
            contextJson = context.toString();
        }

        String answer = anthropicService.chat(question, contextJson);
        return ResponseEntity.ok(Map.of("answer", answer));
    }
}