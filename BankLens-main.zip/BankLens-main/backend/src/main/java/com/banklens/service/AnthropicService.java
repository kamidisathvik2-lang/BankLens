package com.banklens.service;

import com.banklens.dto.AnalysisResponse;
import com.banklens.exception.BankLensExceptions;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Map;

@Service
public class AnthropicService {

    private static final Logger log = LoggerFactory.getLogger(AnthropicService.class);
    private static final String API_URL = "https://api.anthropic.com/v1/messages";
    private static final MediaType JSON_TYPE = MediaType.get("application/json; charset=utf-8");
    private static final int MAX_TEXT_CHARS = 25_000;

    private final OkHttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final String apiKey;
    private final String model;
    private final int maxTokens;

    public AnthropicService(
            @Value("${banklens.anthropic.api-key}") String apiKey,
            @Value("${banklens.anthropic.model}") String model,
            @Value("${banklens.anthropic.max-tokens}") int maxTokens) {
        this.apiKey = apiKey;
        this.model = model;
        this.maxTokens = maxTokens;
        this.objectMapper = new ObjectMapper();
        this.httpClient = new OkHttpClient.Builder()
                .connectTimeout(Duration.ofSeconds(30))
                .readTimeout(Duration.ofSeconds(120))
                .writeTimeout(Duration.ofSeconds(30))
                .build();
    }

    public AnalysisResponse analyzeStatement(String pdfText) {
        // Trim to first 12K chars — captures all transactions, skips legal boilerplate
        String truncated = pdfText.length() > MAX_TEXT_CHARS
                ? pdfText.substring(0, MAX_TEXT_CHARS)
                : pdfText;

        log.info("Sending {} chars to Anthropic (max_tokens={})", truncated.length(), maxTokens);
        String rawResponse = callApi(buildPrompt(truncated));
        return parseResponse(rawResponse);
    }

    private String buildPrompt(String text) {
        return """
                Analyze this bank statement and return a JSON object matching this schema EXACTLY.
                Return ONLY valid JSON. No markdown, no preamble, no explanation.
                Keep summary under 300 characters. Keep riskDescription under 200 characters.
                
                {
                  "period": "string",
                  "account": "string",
                  "totalCredits": 0.0,
                  "totalDebits": 0.0,
                  "netFlow": 0.0,
                  "txnCount": 0,
                  "riskScore": 0,
                  "riskLevel": "low|medium|high",
                  "riskDescription": "string",
                  "summary": "string",
                  "categories": [{"name":"string","emoji":"string","amount":0.0,"pct":0}],
                  "anomalies": ["string"],
                  "transactions": [{"date":"string","desc":"string","category":"string","amount":0.0,"type":"credit|debit","flag":false}]
                }
                
                CRITICAL INSTRUCTIONS:
                - Include ONLY transactions that are explicitly listed in the statement text
                - DO NOT invent, estimate, or pad with fake transactions
                - DO NOT add placeholder rows like "Estimated transactions"
                - If the statement only shows 5 transactions, return exactly 5
                - Payments/credits are type "credit" with positive amount
                - Purchases/debits are type "debit" with negative amount
                - totalDebits must be a negative number (e.g. -1183.19)
                - totalCredits must be a positive number (e.g. 1681.00)
                - netFlow = totalCredits + totalDebits
                - txnCount must equal the exact number of objects in the transactions array
                - riskScore: 0-100 integer
                - Flag transactions: out-of-state, unusually large, unrecognized merchants
                
                Statement text:
                """ + text;
    }

    private String callApi(String prompt) {
        try {
            Map<String, Object> body = Map.of(
                    "model", model,
                    "max_tokens", maxTokens,
                    "system", "You are a financial analyst. Return ONLY valid JSON, no markdown, no preamble. Be concise.",
                    "messages", List.of(Map.of("role", "user", "content", prompt))
            );

            String bodyJson = objectMapper.writeValueAsString(body);
            Request request = new Request.Builder()
                    .url(API_URL)
                    .post(RequestBody.create(bodyJson, JSON_TYPE))
                    .header("x-api-key", apiKey)
                    .header("anthropic-version", "2023-06-01")
                    .header("Content-Type", "application/json")
                    .build();

            try (Response response = httpClient.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    String errorBody = response.body() != null ? response.body().string() : "no body";
                    log.error("Anthropic API error {}: {}", response.code(), errorBody);
                    throw new BankLensExceptions.AnthropicApiException(
                            "Anthropic API returned " + response.code());
                }

                ResponseBody responseBody = response.body();
                if (responseBody == null) {
                    throw new BankLensExceptions.AnthropicApiException("Empty response from Anthropic");
                }

                String responseStr = responseBody.string();
                log.debug("Raw Anthropic response length: {}", responseStr.length());

                var parsed = objectMapper.readTree(responseStr);

                // Check stop reason — if max_tokens hit, response is truncated
                String stopReason = parsed.path("stop_reason").asText("");
                if ("max_tokens".equals(stopReason)) {
                    log.warn("Response hit max_tokens limit — JSON may be truncated");
                }

                return parsed.path("content").get(0).path("text").asText();
            }
        } catch (IOException e) {
            log.error("Failed to call Anthropic API", e);
            throw new BankLensExceptions.AnthropicApiException(
                    "Failed to reach Anthropic API: " + e.getMessage());
        }
    }

    private AnalysisResponse parseResponse(String raw) {
        try {
            String cleaned = raw
                    .replaceAll("```json", "")
                    .replaceAll("```", "")
                    .trim();

            // Attempt to repair truncated JSON
            if (!cleaned.endsWith("}")) {
                log.warn("JSON appears truncated — attempting repair. Last 100 chars: {}",
                        cleaned.substring(Math.max(0, cleaned.length() - 100)));
                cleaned = repairJson(cleaned);
            }

            return objectMapper.readValue(cleaned, AnalysisResponse.class);

        } catch (Exception e) {
            log.error("Failed to parse Anthropic response (first 500 chars): {}",
                    raw.substring(0, Math.min(500, raw.length())));
            throw new BankLensExceptions.AnthropicApiException(
                    "AI response could not be parsed — please try uploading again");
        }
    }

    /**
     * Attempts to close unclosed JSON arrays and objects when Claude hits
     * the max_tokens limit mid-response.
     */
    private String repairJson(String truncated) {
        // Find last valid complete object boundary
        int lastBrace = truncated.lastIndexOf('}');
        if (lastBrace < 0) return truncated;

        String candidate = truncated.substring(0, lastBrace + 1);

        // Count unclosed brackets and braces
        long openSquare  = candidate.chars().filter(c -> c == '[').count()
                         - candidate.chars().filter(c -> c == ']').count();
        long openCurly   = candidate.chars().filter(c -> c == '{').count()
                         - candidate.chars().filter(c -> c == '}').count();

        StringBuilder sb = new StringBuilder(candidate);
        for (long i = 0; i < openSquare; i++) sb.append(']');
        for (long i = 0; i < openCurly;  i++) sb.append('}');

        log.info("JSON repaired: closed {} arrays and {} objects", openSquare, openCurly);
        return sb.toString();
    }
    public String chat(String question, String contextJson) {
        String prompt = """
                You are a helpful financial analyst AI. The user has uploaded a bank statement.
                Answer their question concisely and helpfully using the statement data provided.
                Use specific numbers and dates from the data. Be direct and practical.
                Format your answer clearly — use line breaks and bullet points where helpful.
                
                Statement data:
                """ + contextJson + """
                
                User question: """ + question;

        try {
            Map<String, Object> body = Map.of(
                    "model", model,
                    "max_tokens", 1000,
                    "system", "You are a financial analyst AI. Answer questions about bank statements concisely with specific numbers. Use bullet points for lists.",
                    "messages", List.of(Map.of("role", "user", "content", prompt))
            );

            String bodyJson = objectMapper.writeValueAsString(body);
            Request request = new Request.Builder()
                    .url(API_URL)
                    .post(RequestBody.create(bodyJson, JSON_TYPE))
                    .header("x-api-key", apiKey)
                    .header("anthropic-version", "2023-06-01")
                    .header("Content-Type", "application/json")
                    .build();

            try (Response response = httpClient.newCall(request).execute()) {
                if (!response.isSuccessful() || response.body() == null) {
                    return "Sorry, I could not process that question. Please try again.";
                }
                var parsed = objectMapper.readTree(response.body().string());
                return parsed.path("content").get(0).path("text").asText();
            }
        } catch (Exception e) {
            log.error("Chat API error", e);
            return "Something went wrong. Please try again.";
        }
    }
}