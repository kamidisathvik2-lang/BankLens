package com.banklens.dto;

import java.time.Instant;

public class ErrorResponse {
    private String error;
    private String message;
    private int status;
    private Instant timestamp;

    public ErrorResponse() {}

    public String getError() { return error; }
    public void setError(String error) { this.error = error; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }
    public Instant getTimestamp() { return timestamp; }
    public void setTimestamp(Instant timestamp) { this.timestamp = timestamp; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private final ErrorResponse obj = new ErrorResponse();
        public Builder error(String v) { obj.error = v; return this; }
        public Builder message(String v) { obj.message = v; return this; }
        public Builder status(int v) { obj.status = v; return this; }
        public Builder timestamp(Instant v) { obj.timestamp = v; return this; }
        public ErrorResponse build() { return obj; }
    }
}