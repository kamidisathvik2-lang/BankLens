package com.banklens.dto;

public class AuthResponse {
    private String token;
    private String email;
    private String fullName;

    public AuthResponse() {}
    public AuthResponse(String token, String email, String fullName) {
        this.token = token;
        this.email = email;
        this.fullName = fullName;
    }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public static AuthResponseBuilder builder() { return new AuthResponseBuilder(); }
    public static class AuthResponseBuilder {
        private String token, email, fullName;
        public AuthResponseBuilder token(String t) { this.token = t; return this; }
        public AuthResponseBuilder email(String e) { this.email = e; return this; }
        public AuthResponseBuilder fullName(String f) { this.fullName = f; return this; }
        public AuthResponse build() { return new AuthResponse(token, email, fullName); }
    }
}