package com.banklens.dto;

import java.time.Instant;
import java.util.UUID;

public class AnalysisSummaryDto {
    private UUID id;
    private String period;
    private String account;
    private String fileName;
    private int riskScore;
    private String riskLevel;
    private double totalCredits;
    private double totalDebits;
    private Instant createdAt;

    public AnalysisSummaryDto() {}

    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }
    public String getPeriod() { return period; }
    public void setPeriod(String period) { this.period = period; }
    public String getAccount() { return account; }
    public void setAccount(String account) { this.account = account; }
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
    public int getRiskScore() { return riskScore; }
    public void setRiskScore(int riskScore) { this.riskScore = riskScore; }
    public String getRiskLevel() { return riskLevel; }
    public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }
    public double getTotalCredits() { return totalCredits; }
    public void setTotalCredits(double totalCredits) { this.totalCredits = totalCredits; }
    public double getTotalDebits() { return totalDebits; }
    public void setTotalDebits(double totalDebits) { this.totalDebits = totalDebits; }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private final AnalysisSummaryDto obj = new AnalysisSummaryDto();
        public Builder id(UUID v) { obj.id = v; return this; }
        public Builder period(String v) { obj.period = v; return this; }
        public Builder account(String v) { obj.account = v; return this; }
        public Builder fileName(String v) { obj.fileName = v; return this; }
        public Builder riskScore(int v) { obj.riskScore = v; return this; }
        public Builder riskLevel(String v) { obj.riskLevel = v; return this; }
        public Builder totalCredits(double v) { obj.totalCredits = v; return this; }
        public Builder totalDebits(double v) { obj.totalDebits = v; return this; }
        public Builder createdAt(Instant v) { obj.createdAt = v; return this; }
        public AnalysisSummaryDto build() { return obj; }
    }
}