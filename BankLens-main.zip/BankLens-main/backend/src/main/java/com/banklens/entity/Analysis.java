package com.banklens.entity;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "analyses")
@EntityListeners(AuditingEntityListener.class)
public class Analysis {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "file_name", length = 255)
    private String fileName;

    @Column(name = "period", length = 100)
    private String period;

    @Column(name = "account", length = 100)
    private String account;

    @Column(name = "analysis_json", columnDefinition = "TEXT", nullable = false)
    private String analysisJson;

    @Column(name = "risk_score")
    private Integer riskScore;

    @Column(name = "risk_level", length = 20)
    private String riskLevel;

    @Column(name = "total_credits")
    private Double totalCredits;

    @Column(name = "total_debits")
    private Double totalDebits;

    @CreatedDate
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    public Analysis() {}

    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
    public String getPeriod() { return period; }
    public void setPeriod(String period) { this.period = period; }
    public String getAccount() { return account; }
    public void setAccount(String account) { this.account = account; }
    public String getAnalysisJson() { return analysisJson; }
    public void setAnalysisJson(String analysisJson) { this.analysisJson = analysisJson; }
    public Integer getRiskScore() { return riskScore; }
    public void setRiskScore(Integer riskScore) { this.riskScore = riskScore; }
    public String getRiskLevel() { return riskLevel; }
    public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }
    public Double getTotalCredits() { return totalCredits; }
    public void setTotalCredits(Double totalCredits) { this.totalCredits = totalCredits; }
    public Double getTotalDebits() { return totalDebits; }
    public void setTotalDebits(Double totalDebits) { this.totalDebits = totalDebits; }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }

    public static AnalysisBuilder builder() { return new AnalysisBuilder(); }

    public static class AnalysisBuilder {
        private UUID id;
        private User user;
        private String fileName;
        private String period;
        private String account;
        private String analysisJson;
        private Integer riskScore;
        private String riskLevel;
        private Double totalCredits;
        private Double totalDebits;
        private Instant createdAt;

        public AnalysisBuilder id(UUID id) { this.id = id; return this; }
        public AnalysisBuilder user(User user) { this.user = user; return this; }
        public AnalysisBuilder fileName(String f) { this.fileName = f; return this; }
        public AnalysisBuilder period(String p) { this.period = p; return this; }
        public AnalysisBuilder account(String a) { this.account = a; return this; }
        public AnalysisBuilder analysisJson(String j) { this.analysisJson = j; return this; }
        public AnalysisBuilder riskScore(Integer r) { this.riskScore = r; return this; }
        public AnalysisBuilder riskLevel(String r) { this.riskLevel = r; return this; }
        public AnalysisBuilder totalCredits(Double t) { this.totalCredits = t; return this; }
        public AnalysisBuilder totalDebits(Double t) { this.totalDebits = t; return this; }
        public AnalysisBuilder createdAt(Instant c) { this.createdAt = c; return this; }

        public Analysis build() {
            Analysis a = new Analysis();
            a.id = this.id;
            a.user = this.user;
            a.fileName = this.fileName;
            a.period = this.period;
            a.account = this.account;
            a.analysisJson = this.analysisJson;
            a.riskScore = this.riskScore;
            a.riskLevel = this.riskLevel;
            a.totalCredits = this.totalCredits;
            a.totalDebits = this.totalDebits;
            a.createdAt = this.createdAt;
            return a;
        }
    }
}