import { useState, useRef, useCallback, useEffect } from "react";
import './App.css';

const API = process.env.REACT_APP_API_URL || "http://localhost:8080";

// ─── API HELPERS ──────────────────────────────────────────────────────────────
const http = {
  async post(path, body, token) {
    const res = await fetch(`${API}${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || `Error ${res.status}`);
    return data;
  },
  async get(path, token) {
    const res = await fetch(`${API}${path}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || `Error ${res.status}`);
    return data;
  },
  async upload(path, file, token) {
    const form = new FormData();
    form.append("file", file);
    const res = await fetch(`${API}${path}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
      body: form,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || `Error ${res.status}`);
    return data;
  },
  async del(path, token) {
    const res = await fetch(`${API}${path}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.message || `Error ${res.status}`);
    }
  },
};

// ─── ANIMATED NUMBER ──────────────────────────────────────────────────────────
function AnimNum({ value, prefix = "", dur = 900 }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    const t0 = Date.now();
    const tick = () => {
      const p = Math.min((Date.now() - t0) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setN(Math.round(eased * value));
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [value, dur]);
  return <>{prefix}{n.toLocaleString()}</>;
}

// ─── AUTH SCREEN ──────────────────────────────────────────────────────────────
function AuthScreen({ onAuth }) {
  const [mode,    setMode]    = useState("login");
  const [email,   setEmail]   = useState("");
  const [pass,    setPass]    = useState("");
  const [name,    setName]    = useState("");
  const [error,   setError]   = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const path = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const body = mode === "login"
        ? { email, password: pass }
        : { email, password: pass, fullName: name };
      const data = await http.post(path, body);
      onAuth(data.token, data.email, data.fullName);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <div className="auth-brand">
          <div className="hdr-dot" style={{ display: "inline-block", marginRight: 8 }} />
          BankLens
        </div>
        <h2 className="auth-title">
          {mode === "login" ? "Sign in to your account" : "Create your account"}
        </h2>
        <form onSubmit={submit} className="auth-form">
          {mode === "register" && (
            <div className="field">
              <label>Full name</label>
              <input type="text" value={name} onChange={e => setName(e.target.value)}
                placeholder="Your full name" required minLength={2} />
            </div>
          )}
          <div className="field">
            <label>Email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)}
              placeholder="you@example.com" required />
          </div>
          <div className="field">
            <label>Password</label>
            <input type="password" value={pass} onChange={e => setPass(e.target.value)}
              placeholder={mode === "register" ? "Min 8 characters" : ""}
              required minLength={mode === "register" ? 8 : 1} />
          </div>
          {error && <div className="auth-error">{error}</div>}
          <button type="submit" className="btn-primary"
            disabled={loading}
            style={{ width: "100%", justifyContent: "center" }}>
            {loading ? "Please wait..." : mode === "login" ? "Sign in" : "Create account"}
          </button>
        </form>
        <div className="auth-switch">
          {mode === "login"
            ? <>No account? <button onClick={() => { setMode("register"); setError(""); }}>Register</button></>
            : <>Already registered? <button onClick={() => { setMode("login"); setError(""); }}>Sign in</button></>
          }
        </div>
      </div>
    </div>
  );
}

// ─── HISTORY PANEL ────────────────────────────────────────────────────────────
function HistoryPanel({ token, onSelect, onClose }) {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    http.get("/api/analyses", token)
      .then(setHistory)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [token]);

  const handleDelete = async (id, e) => {
    e.stopPropagation();
    await http.del(`/api/analyses/${id}`, token).catch(console.error);
    setHistory(h => h.filter(a => a.id !== id));
  };

  return (
    <div className="history-overlay" onClick={onClose}>
      <div className="history-panel" onClick={e => e.stopPropagation()}>
        <div className="history-head">
          <span style={{ fontFamily: "var(--sans)", fontWeight: 700 }}>Past Analyses</span>
          <button className="btn-outline" onClick={onClose}>Close</button>
        </div>
        {loading && (
          <div style={{ padding: "24px", color: "var(--muted)" }}>Loading...</div>
        )}
        {!loading && history.length === 0 && (
          <div style={{ padding: "24px", color: "var(--muted)" }}>No analyses yet.</div>
        )}
        {history.map(a => (
          <div key={a.id} className="history-item"
            onClick={() => { onSelect(a.id); onClose(); }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: 13 }}>{a.period}</div>
              <div style={{ fontSize: 11, color: "var(--muted)", fontFamily: "var(--mono)" }}>
                {a.account} · {a.fileName}
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{
                fontSize: 11, fontFamily: "var(--mono)",
                color: a.riskLevel === "high" ? "var(--red)"
                  : a.riskLevel === "medium" ? "var(--amber)" : "var(--green)"
              }}>
                {a.riskScore}/100
              </span>
              <button className="btn-outline" style={{ fontSize: 11, padding: "3px 8px" }}
                onClick={e => handleDelete(a.id, e)}>
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── EXPLAIN MODAL ────────────────────────────────────────────────────────────
function ExplainModal({ txn, onClose }) {
  const [loading, setLoading] = useState(true);
  const [text,    setText]    = useState("");
  const [verdict, setVerdict] = useState("warn");

  useEffect(() => {
    let cancelled = false;
    setTimeout(() => {
      if (cancelled) return;
      const outOfState = /VA|NJ|GA|SC|NY|FL|CA|CO|TX/.test(txn.desc || "");
      const isLarge    = Math.abs(txn.amount) > 150;
      const isUnknown  = txn.category === "Unknown" || txn.category === "International";

      if (isUnknown || (outOfState && isLarge)) {
        setText("This transaction is outside your typical spending pattern. The merchant or location does not match your usual activity. Verify you recognize this charge. If not, contact your bank immediately to dispute it — most banks require disputes within 60 days.");
        setVerdict("risk");
      } else if (outOfState || isLarge) {
        setText("This transaction was either in an unfamiliar location or above your typical spend amount. If you were traveling or made a large purchase intentionally, no action is needed. Otherwise verify with your bank.");
        setVerdict("warn");
      } else {
        setText("This transaction was flagged based on your spending patterns but appears within normal parameters. No immediate action required. Keep an eye on similar charges going forward.");
        setVerdict("safe");
      }
      if (!cancelled) setLoading(false);
    }, 1200);
    return () => { cancelled = true; };
  }, []); // eslint-disable-line

  const VL = { safe: "Likely Safe", warn: "Verify This", risk: "Act Immediately" };
  const VC = { safe: "vs", warn: "vw", risk: "vr" };
  const VI = { safe: "✓", warn: "⚠", risk: "⚡" };

  return (
    <div className="mbk" onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal">
        <div className="mhdr">
          <div className="mtitle">Transaction Explanation</div>
          <button className="mclose" onClick={onClose}>✕</button>
        </div>
        <div className="mbody">
          <div className="mtxn">
            <div className="mtxn-l">
              <div className="md">{txn.desc}</div>
              <div className="ms">{txn.date} · {txn.category}</div>
            </div>
            <div className={txn.type === "credit" ? "tcr" : "tdb"}>
              {txn.type === "credit" ? "+" : "-"}${Math.abs(txn.amount).toLocaleString()}
            </div>
          </div>
          {loading
            ? <div className="mload">
                <div className="dots">
                  <span>●</span><span>●</span><span>●</span>
                </div>
                Analyzing...
              </div>
            : <div className="mexpl">
                {text}
                <div style={{ marginTop: 12 }}>
                  <span className={`verdict ${VC[verdict]}`}>{VI[verdict]} {VL[verdict]}</span>
                </div>
              </div>
          }
        </div>
      </div>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [token,     setToken]     = useState(() => sessionStorage.getItem("bl_token") || null);
const [userEmail, setUserEmail] = useState(() => sessionStorage.getItem("bl_email") || "");
const [userName,  setUserName]  = useState(() => sessionStorage.getItem("bl_name") || "");
  const [file,      setFile]      = useState(null);
  const [drag,      setDrag]      = useState(false);
  const [proc,      setProc]      = useState(false);
  const [step,      setStep]      = useState(0);
  const [data,      setData]      = useState(null);
  const [error,     setError]     = useState("");
  const [explain,   setExplain]   = useState(null);
  const [showHist,  setShowHist]  = useState(false);
  const [remaining, setRemaining] = useState(null);
  const [msgs,      setMsgs]      = useState([]);
  const [cin,       setCin]       = useState("");
  const [busy,      setBusy]      = useState(false);

  const fRef = useRef(null);
  const cEnd = useRef(null);

  useEffect(() => {
    cEnd.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs]);

  useEffect(() => {
    if (token) {
      http.get("/api/analyses/remaining", token)
        .then(d => setRemaining(d.remaining))
        .catch(() => {});
    }
  }, [token, data]);

  const handleAuth = (tok, email, name) => {
  sessionStorage.setItem("bl_token", tok);
  sessionStorage.setItem("bl_email", email);
  sessionStorage.setItem("bl_name", name);
  setToken(tok);
  setUserEmail(email);
  setUserName(name);
};

  const logout = () => {
  sessionStorage.removeItem("bl_token");
  sessionStorage.removeItem("bl_email");
  sessionStorage.removeItem("bl_name");
  setToken(null); setUserEmail(""); setUserName("");
  setData(null); setFile(null); setMsgs([]); setError("");
};

  const STEPS = [
    "Reading PDF",
    "Parsing transactions",
    "Categorizing spend",
    "Scoring risk",
    "Generating summary",
  ];

  const process = async (f) => {
    setFile(f); setProc(true); setStep(0); setError("");
    try {
      for (let i = 0; i < 4; i++) {
        setStep(i);
        await new Promise(r => setTimeout(r, 500));
      }
      const result = await http.upload("/api/analyses", f, token);
      setStep(4);
      await new Promise(r => setTimeout(r, 300));
      setData(result);
      setMsgs([{
        r: "ai",
        t: `Analyzed ${result.period} — ${result.txnCount} transactions, ${result.anomalies?.length || 0} flagged. Ask me anything.`,
      }]);
    } catch (err) {
      setError(err.message || "Analysis failed. Please try again.");
      setFile(null);
    }
    setProc(false);
  };

  const loadHistoryItem = async (id) => {
    try {
      const result = await http.get(`/api/analyses/${id}`, token);
      setData(result);
      setFile({ name: result.fileName });
      setMsgs([{ r: "ai", t: `Loaded: ${result.period}. Ask me anything about it.` }]);
    } catch {
      setError("Failed to load analysis.");
    }
  };

  const onDrop = useCallback(e => {
    e.preventDefault(); setDrag(false);
    const f = e.dataTransfer.files[0];
    if (f) process(f);
  }, [token]); // eslint-disable-line

  const chat = async () => {
  if (!cin.trim() || busy) return;
  const q = cin.trim(); setCin("");
  setMsgs(m => [...m, { r: "user", t: q }]);
  setBusy(true);
  try {
    const context = {
      period: data?.period,
      account: data?.account,
      totalCredits: data?.totalCredits,
      totalDebits: data?.totalDebits,
      netFlow: data?.netFlow,
      txnCount: data?.txnCount,
      riskScore: data?.riskScore,
      riskLevel: data?.riskLevel,
      riskDescription: data?.riskDescription,
      categories: data?.categories,
      anomalies: data?.anomalies,
      transactions: data?.transactions,
    };

    const res = await http.post("/api/chat", {
      question: q,
      context: context,
    }, token);

    setMsgs(m => [...m, { r: "ai", t: res.answer }]);
  } catch {
    setMsgs(m => [...m, { r: "ai", t: "Something went wrong. Try again." }]);
  }
  setBusy(false);
};

  const circ = 2 * Math.PI * 28;
  const rOff = data ? circ - (data.riskScore / 100) * circ : circ;
  const rCol = data?.riskLevel === "high" ? "#E8351A"
    : data?.riskLevel === "medium" ? "#F59E0B" : "#16A34A";

  const statRows = data ? [
    { nm: "Credits",      val: data.totalCredits,      pre: "$",                             col: "var(--green)", hint: "this period"  },
    { nm: "Debits",       val: Math.abs(data.totalDebits),       pre: "$",                             col: "var(--red)",   hint: "this period"  },
    { nm: "Net Flow",     val: Math.abs(data.netFlow), pre: data.netFlow >= 0 ? "+$" : "-$", col: data.netFlow >= 0 ? "var(--green)" : "var(--red)", hint: data.netFlow >= 0 ? "surplus" : "deficit" },
    { nm: "Transactions", val: data.txnCount,          pre: "",                              col: "var(--blue)",  hint: "this month"   },
  ] : [];

  const sugg = [
    "How much am I saving?",
    "My largest expenses",
    "Explain flagged items",
    "What is my risk score?",
  ];

  if (!token) return <AuthScreen onAuth={handleAuth} />;

  return (
    <>
      {/* HEADER */}
      <header className="hdr">
        <div className="hdr-logo"><div className="hdr-dot" />BankLens</div>
        <div className="hdr-r">
          {remaining !== null && (
            <div className="hdr-st">{remaining} analyses left today</div>
          )}
          <div className="hdr-st">{userEmail}</div>
          <button className="btn-outline" style={{ fontSize: 11 }}
            onClick={() => setShowHist(true)}>History</button>
          <button className="btn-outline" style={{ fontSize: 11 }}
            onClick={logout}>Sign out</button>
        </div>
      </header>

      <div className="wrap">

        {/* UPLOAD SCREEN */}
        {!file && !proc && !data && (
          <div className="upload-section">
            <div className="eyebrow">Financial Intelligence</div>
            <h1 className="headline">
              Welcome back, <em>{userName.split(" ")[0]}</em>.<br />
              Upload a statement.
            </h1>
            <p className="sub">
              Drop a PDF bank statement. The server reads every transaction,
              categorizes your spending, flags anomalies, and stores your history securely.
            </p>
            {error && (
              <div className="notice"
                style={{ borderColor: "#FAD4CC", background: "#FFF8F7", color: "var(--red)" }}>
                <span>⚠</span><span>{error}</span>
              </div>
            )}
            <div className={`drop${drag ? " drag" : ""}`}
              onDragOver={e => { e.preventDefault(); setDrag(true); }}
              onDragLeave={() => setDrag(false)}
              onDrop={onDrop}
              onClick={() => fRef.current?.click()}
            >
              <span className="drop-icon">📄</span>
              <div className="drop-label">Drop your PDF statement here</div>
              <div className="drop-sub">or click to browse</div>
              <button className="btn-primary"
                onClick={e => { e.stopPropagation(); fRef.current?.click(); }}>
                Choose PDF
              </button>
              <div className="drop-fmt">PDF · up to 10MB · processed securely server-side</div>
              <input ref={fRef} type="file" accept=".pdf" style={{ display: "none" }}
                onChange={e => { const f = e.target.files[0]; if (f) process(f); }} />
            </div>
          </div>
        )}

        {/* PROCESSING SCREEN */}
        {proc && (
          <div className="proc">
            <div className="proc-title">Analyzing statement</div>
            <div className="proc-sub">
              Apache PDFBox extracts text server-side · Claude analyzes it
            </div>
            <div className="proc-steps">
              {STEPS.map((s, i) => (
                <div key={i}
                  className={`pstep${i < step ? " done" : i === step ? " active" : ""}`}>
                  <div className="ptrack" />{i < step ? "✓ " : ""}{s}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* DASHBOARD */}
        {data && !proc && (
          <div className="dash">
            <div className="topbar">
              <div>
                <div className="topbar-kicker">
                  {typeof file === "object" && file?.name ? file.name : "statement.pdf"}
                </div>
                <div className="topbar-title">{data.period} · {data.account}</div>
              </div>
              <button className="btn-outline"
                onClick={() => { setData(null); setFile(null); setMsgs([]); setError(""); }}>
                ← New statement
              </button>
            </div>

            {/* Stats */}
            <div className="stats">
              {statRows.map((s, i) => (
                <div className="stat" key={i}>
                  <div className="stat-accent" style={{ background: s.col }} />
                  <div className="stat-nm">{s.nm}</div>
                  <div className="stat-n" style={{ color: s.col }}>
                    <AnimNum value={s.val} prefix={s.pre} />
                  </div>
                  <div className="stat-h">{s.hint}</div>
                </div>
              ))}
            </div>

            {/* Risk + Categories */}
            <div className="two">
              <div className="panel">
                <div className="ph"><div className="ph-label">Risk Assessment</div></div>
                <div className="pb">
                  <div className="risk-wrap">
                    <div className="rmeter">
                      <svg className="rsvg" viewBox="0 0 72 72">
                        <circle className="rtrack" cx="36" cy="36" r="28" />
                        <circle className="rfill" cx="36" cy="36" r="28"
                          stroke={rCol}
                          strokeDasharray={circ}
                          strokeDashoffset={rOff} />
                      </svg>
                      <div className="rnum" style={{ color: rCol }}>{data.riskScore}</div>
                    </div>
                    <div>
                      <div className="rlv" style={{ color: rCol }}>
                        {data.riskLevel === "high" ? "High Risk"
                          : data.riskLevel === "medium" ? "Medium Risk" : "Low Risk"}
                      </div>
                      <div className="rdesc">{data.riskDescription}</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="panel">
                <div className="ph"><div className="ph-label">Spending Breakdown</div></div>
                <div className="pb">
                  <div className="cats">
                    {(data.categories || []).slice(0, 6).map((c, i) => (
                      <div className="cat-row" key={i}>
                        <span className="cem">{c.emoji}</span>
                        <span className="cnm">{c.name}</span>
                        <div className="ctrack">
                          <div className="cbar" style={{ width: `${c.pct}%` }} />
                        </div>
                        <span className="cval">${c.amount?.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Summary */}
            <div className="fp panel">
              <div className="ph"><div className="ph-label">AI Financial Summary</div></div>
              <div className="pb">
                <div className="sum-body">{data.summary}</div>
              </div>
            </div>

            {/* Anomalies */}
            {data.anomalies?.length > 0 && (
              <div className="fp panel">
                <div className="ph">
                  <div className="ph-label">Flagged Items</div>
                  <div className="flag-count">{data.anomalies.length} flagged</div>
                </div>
                <div className="pb">
                  <div className="alist">
                    {data.anomalies.map((a, i) => (
                      <div className="aitem" key={i}>
                        <div className="apip" />{a}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Transactions */}
            <div className="fp panel">
              <div className="ph">
                <div className="ph-label">
                  Transactions
                  {data.transactions?.length > 0 && (
                    <span style={{ fontWeight: 400, color: "var(--muted)", marginLeft: 8 }}>
                      ({data.transactions.length})
                    </span>
                  )}
                </div>
                <div className="table-hint">click ⚠ to explain</div>
              </div>
              <div className="tscroll">
                <table className="txns">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Description</th>
                      <th>Category</th>
                      <th className="align-right">Amount</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(data.transactions || []).map((t, i) => (
                      <tr key={i}>
                        <td className="td-date">{t.date}</td>
                        <td className={t.flag ? "td-flagged" : ""}>{t.desc}</td>
                        <td><span className="cpill">{t.category}</span></td>
                        <td className="align-right">
                          <span className={t.type === "credit" ? "tcr" : "tdb"}>
                            {t.type === "credit" ? "+" : "-"}${Math.abs(t.amount).toLocaleString()}
                          </span>
                        </td>
                        <td>
                          {t.flag
                            ? <button className="fpill" onClick={() => setExplain(t)}>⚠ Explain</button>
                            : <span className="td-clear">—</span>
                          }
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Chat */}
            <div className="fp panel">
              <div className="ph"><div className="ph-label">Ask About Your Statement</div></div>
              <div className="pb">
                <div className="chips">
                  {sugg.map((s, i) => (
                    <button key={i} className="chip" onClick={() => setCin(s)}>{s}</button>
                  ))}
                </div>
                <div className="chat-msgs">
                  {msgs.map((m, i) => (
                    <div key={i} className={`crow${m.r === "user" ? " user" : ""}`}>
                      <div className={`cav ${m.r}`}>
                        {m.r === "ai" ? "AI" : userName.charAt(0).toUpperCase()}
                      </div>
                      <div
                          className={`cbub${m.r === "user" ? " user" : ""}`}
                          dangerouslySetInnerHTML={{
                            __html: m.t
                              .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
                              .replace(/^# (.+)$/gm, '<div class="chat-h1">$1</div>')
                              .replace(/^## (.+)$/gm, '<div class="chat-h2">$1</div>')
                              .replace(/^### (.+)$/gm, '<div class="chat-h3">$1</div>')
                              .replace(/^• (.+)$/gm, '<div class="chat-li">$1</div>')
                              .replace(/^\d+\. \*\*(.+?)\*\*(.*)$/gm, '<div class="chat-li"><strong>$1</strong>$2</div>')
                              .replace(/^\d+\. (.+)$/gm, '<div class="chat-li">$1</div>')
                              .replace(/\n{2,}/g, '<div class="chat-gap"></div>')
                              .replace(/\n/g, ' ')
                          }}
                        />
                    </div>
                  ))}
                  {busy && (
                    <div className="crow">
                      <div className="cav ai">AI</div>
                      <div className="cbub">
                        <span className="dots">
                          <span>●</span><span>●</span><span>●</span>
                        </span>
                      </div>
                    </div>
                  )}
                  <div ref={cEnd} />
                </div>
                <div className="cinrow">
                  <input className="cin"
                    placeholder="Ask about your transactions or spending..."
                    value={cin}
                    onChange={e => setCin(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && chat()} />
                  <button className="csend" onClick={chat} disabled={busy || !cin.trim()}>
                    Send →
                  </button>
                </div>
              </div>
            </div>

          </div>
        )}
      </div>

      {/* History Panel */}
      {showHist && (
        <HistoryPanel
          token={token}
          onSelect={loadHistoryItem}
          onClose={() => setShowHist(false)} />
      )}

      {/* Explain Modal */}
      {explain && (
        <ExplainModal txn={explain} onClose={() => setExplain(null)} />
      )}
    </>
  );
}